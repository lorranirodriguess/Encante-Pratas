const currency = (value) => `$${Number(value).toFixed(2)}`;
const getCart = () => JSON.parse(localStorage.getItem("bloomCart") || "[]");
const saveCart = (cart) => {
  localStorage.setItem("bloomCart", JSON.stringify(cart));
  updateCartBadge();
};
function updateCartBadge() {
  const total = getCart().reduce((sum, item) => sum + item.quantity, 0);
  document.querySelectorAll(".cart-badge").forEach((el) => {
    el.textContent = total;
    el.classList.toggle("show", total > 0);
  });
}
function addToCart(id) {
  const cart = getCart(),
    item = cart.find((entry) => entry.id === id);
  item ? item.quantity++ : cart.push({ id, quantity: 1 });
  saveCart(cart);
  showToast("Product added to your cart.");
}
function showToast(message) {
  const el = document.querySelector("#appToast");
  if (!el) return;
  el.querySelector(".toast-body").textContent = message;
  bootstrap.Toast.getOrCreateInstance(el).show();
}
function productCard(product) {
  return `<div class="col"><article class="card h-100 shadow-sm product-card"><div class="product-image-wrap"><img class="product-image" src="${product.image}" alt="${product.name}" loading="lazy"><button class="favorite" type="button" aria-label="Favorite ${product.name}"><i class="bi bi-heart"></i></button><div class="quick-view"><a class="btn btn-bloom" href="product.html?id=${product.id}"><i class="bi bi-eye me-1"></i> Quick View</a></div></div><div class="card-body d-flex flex-column p-3"><a class="text-decoration-none text-dark" href="product.html?id=${product.id}"><h2 class="product-title">${product.name}</h2></a><strong class="fs-5 my-3">${currency(product.price)}</strong><button class="btn btn-bloom mt-auto add-product" data-id="${product.id}"><i class="bi bi-cart-plus me-1"></i> Add to Cart</button></div></article></div>`;
}
function renderProducts(list = products) {
  const grid = document.querySelector("#productGrid");
  if (!grid) return;
  grid.innerHTML = list.length
    ? list.map(productCard).join("")
    : '<div class="col-12 text-center py-5"><div class="fs-1">🔎</div><h2 class="h4 mt-3">No products found</h2><p class="text-secondary">Try another search term.</p></div>';
}
document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  renderProducts();
  document.addEventListener("click", (event) => {
    const favorite = event.target.closest(".favorite"),
      add = event.target.closest(".add-product");
    if (favorite) {
      favorite.classList.toggle("active");
      favorite.innerHTML = favorite.classList.contains("active")
        ? '<i class="bi bi-heart-fill"></i>'
        : '<i class="bi bi-heart"></i>';
    }
    if (add) addToCart(Number(add.dataset.id));
  });
  const search = document.querySelector("#productSearch");
  if (search)
    search.addEventListener("input", (e) =>
      renderProducts(
        products.filter((p) =>
          p.name.toLowerCase().includes(e.target.value.toLowerCase()),
        ),
      ),
    );
  document.querySelectorAll(".newsletter-form").forEach((form) =>
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      form.reset();
      showToast("Thank you for subscribing!");
    }),
  );
});
