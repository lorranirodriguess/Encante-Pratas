# BloomShop Static Template

This directory is a standalone front-end template. It uses only HTML, CSS, JavaScript, Bootstrap 5, and Bootstrap Icons loaded from CDN.

## Structure

- `index.html` — product catalogue and search
- `contact.html` — complete contact, support, FAQ, and call-to-action page
- `cart.html` — interactive cart, shipping, tax, order summary, and recommendations
- `product.html?id=1` — product details, quantity selector, buy now, favourites, share, benefits, and related products
- `assets/css/style.css` — custom styles
- `assets/js/products.js` — catalogue data
- `assets/js/main.js` — search, favourites, newsletter, and cart logic

Open `index.html` in a browser. The cart persists in the browser through `localStorage`. Checkout, account, form delivery, and live chat remain demo-only because they require a backend service.
